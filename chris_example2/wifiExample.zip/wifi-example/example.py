#!/usr/bin/env python

from flask import Flask, render_template, request, g
app = Flask(__name__)

values = {"position": "?"}

@app.route("/")
def hello():
  return render_template('example.html', value=values["position"])

@app.route("/set")
def set_position():
  values["position"] = int(request.args.get('position'))
  return ""

if __name__ == "__main__":
    app.run("", 5001, debug=True)

